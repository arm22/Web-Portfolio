#!/usr/bin/perl
# This script helps prepare a cross-platform PixelMath demo, and it assumes you
# already have a folder of demos containing at least the load-mona demo, which
# serves as a prototype for this process.
# By Steve Tanimoto, January 7, 2015.

print "This is make-demo.pl, attempting to make a PixelMath clickable demo...\n\n";
print "Usage: (from within the lib/ folder)\n";
print "./make-demo.pl myDemo.py\n\n";

print "The first argument must be the name of a Python file representing the demo.\n";
print "For example, it could be named:  myDemo.py  \n";
print "This file should already exist (although it does not have to work properly";
print "in order to get the demo infrastructure set up).\n";
print "This Python file should be placed in the top-level demos folder, and\n";
print "not in a subfolder, because this script will create the subfolder for\n";
print "you and move the Python file into it.\n\n";

print "Verbose comments are printed below, in case anything goes wrong.\n";
print "The user argument is: " . $ARGV[0] . "\n" ;

print "Extracting the demo name from the full Python file name...\n";
my $pyFileName = $ARGV[0];
if (not $pyFileName =~ /^(.*).py$/) {
    die("FATAL ERROR: $pyFileName does not end in .py and might not be a Python file.");
}
my $demoName = $1;
print "Creating the subfolder: $demoName.\n";
chdir "../";
mkdir $demoName;
chdir "lib";

print "Creating an AppStart properties file by copying most lines from the load-mona demo.\n";
print "Editing the properties file.\n";
print "The only line we change is the one that specifies what Python file PixelMath should run.\n";
open FH, "<../load-mona/load-mona.properties";
my $newPropertiesFileName = $demoName . ".properties";
open GH, ">../$demoName/$newPropertiesFileName";
while (<FH>)
{
    if (/for-pixelmath=--init=load-mona\/load-mona\.py/) {
	print GH "for-pixelmath=--init=" . $demoName . "/" . $pyFileName . "\n";
    }
    else {print GH $_;}
}
close FH;
close GH;

print "Creating a copy of the AppStart file (aka load-mona.jar) with the name $demoName.jar.\n";
use File::Copy;
copy("../load-mona.jar", "../$demoName.jar") or die "Failed to copy load-mona.jar.";

print "Moving the Python file into the folder.";
move("../$pyFileName","../$demoName/") or die "Failed to move the Python file: $!";

print "ALL DONE!\n\n";
print "Now put any image files or other PixelMath resource files into your demo subfolder, test your demo, and correct any paths within the demo so everything loads properly.\n";


