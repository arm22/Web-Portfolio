This is the Final Project for CSE 190D:
"Pixels, Numbers, and Programs: Visual Computing with Python"
Winter Quarter 2015 at 
The University of Washington in Seattle, WA.

It was built by Austin Meyers, Colin Bartels, 
and Steven Yong to complete the Final Project requirement
for the previously mentioned course.

The goal of this project is to educate players
on basic image transformations.

To achieve this goal we built an entire game 
based in he programming language Python and
implementing the Java Swing library as well as 
an image processing library called "PixelMath".

This folder allows you to to play the game with 1 click,
by opening the "2x2FinalProject.jar" file which will launch 
a single instance of the "2x2ImageTransformationGame".
It also containts all the code and libraries to allow
others to learn about the workings of the game. These
can be found in the "2x2FinalProject" folder.
The "2x2FinalProject.py" file containts the raw
Python code (this interfaces with the PixelMath library).
The "images" folder contains a library of JPEG images
used within the game. The "1.txt" file is a library
of transformation functions also used within the games.

To play the game, open the "2x2FinalProject.jar" file.
The original image will be on the lower left of the screen
and after being split, the program applies 4 
random transformations. The goal of the user is to guess 
what function is applied to which section of the image.
The functions are found above groups of buttons. Choose 
which section the function was applied to. If the answer is
incorrect the button will turn red. If the answer is correct
the button will turn gree, and the formula will dissappear. 

After successfully choosing all 4 function/section pairs
you have won the game! There is no end screen,
simply exit the window to close the game.

Enjoy!
