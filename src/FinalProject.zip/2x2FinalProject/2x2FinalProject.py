#Written by Austin Meyers
from java.util import Random
from javax.swing import JButton, JFrame, JLabel, JPanel, JButton, ImageIcon
from java.awt import GridLayout, Color, Font

lister = []
def generateImage():
	import os, random
	img = random.choice(os.listdir("2x2FinalProject/images/"))
	pmOpenImage(1, "2x2FinalProject/images/" + img, "512, 512")
	pmSetVisible(1, False)
	pmSaveImageAs(1, "2x2FinalProject/OriginalImage.jpg")
	print "Random Image Generated"
	
	pmNewImage(2, "1", 256, 256, 0, 0, 0)
	pmSetVisible(2, False)
	pmSetSource1(1)
	pmSetDestination(2)
	pmSetFormula("S1(x, y + 256)")
	pmCompute()

	pmNewImage(3, "2", 256, 256, 0, 0, 0)
	pmSetVisible(3, False)
	pmSetSource1(1)
	pmSetDestination(3)
	pmSetFormula("S1(x + 256, y + 256)")
	pmCompute()

	pmNewImage(4, "3", 256, 256, 0, 0, 0)
	pmSetVisible(4, False)
	pmSetSource1(1)
	pmSetDestination(4)
	pmSetFormula("S1(x, y)")
	pmCompute()

	pmNewImage(5, "4", 256, 256, 0, 0, 0)
	pmSetVisible(5, False)
	pmSetSource1(1)
	pmSetDestination(5)
	pmSetFormula("S1(x + 256, y)")
	pmCompute()

def distortImage():
	global lister
	def transformImage(wn, formula_lib):
		from random import randint
		import linecache
		pmSetSource1(wn)
		pmSetDestination(wn)
		lib = open(formula_lib)
		num_lines = sum(1 for line in lib)
		num = randint(0, num_lines - 1)
		formulas = linecache.getline(formula_lib, num)
		pmSetFormula(formulas)
		pmCompute()
		lister.append(formulas)
	
	def combine():
		pmNewImage(6, "New Image", 512, 512, 0, 0, 0)
		pmSetVisible(6, False)
		pmSetDestination(6)
		pmSetSource2(6)
		pmSetSource1(2)
		pmSetFormula("if x < 256 and y >= 256 then S1(x, y - 256) else S2(x, y)")
		pmCompute()
		pmSetSource1(3)
		pmSetFormula("if x >= 256 and y >= 256 then S1(x - 256, y - 256) else S2(x, y)")
		pmCompute()
		pmSetSource1(4)
		pmSetFormula("if x < 256 and y < 256 then S1(x, y) else S2(x, y)")
		pmCompute()
		pmSetSource1(5)
		pmSetFormula("if x >= 256 and y < 256 then S1(x - 256, y) else S2(x, y)")
		pmCompute()
		pmSaveImageAs(6, "2x2FinalProject/Transformed.jpg")
		
	for i in range(2, 6):
		transformImage(i, "2x2FinalProject/1.txt")
	combine()
	print "Split and Distorted Image Generated"
	
class openPane():
	print "Creating User Interface"
	global lister
	
	def TLCheck1(self, event):
		self.label1.setText("Correct!")
		self.TLButton1.setBackground(Color.green)
	def TRCheck1(self, event):
		self.TRButton1.setBackground(Color.red)
	def BLCheck1(self, event):
		self.BLButton1.setBackground(Color.red)
	def BRCheck1(self, event):
		self.BRButton1.setBackground(Color.red)

	def TLCheck2(self, event):
		self.TLButton2.setBackground(Color.red)
	def TRCheck2(self, event):
		self.label2.setText("Correct!")
		self.TRButton2.setBackground(Color.green)
	def BLCheck2(self, event):
		self.BLButton2.setBackground(Color.red)
	def BRCheck2(self, event):
		self.BRButton2.setBackground(Color.red)

	def TLCheck3(self, event):
		self.TLButton3.setBackground(Color.red)
	def TRCheck3(self, event):
		self.TRButton3.setBackground(Color.red)
	def BLCheck3(self, event):
		self.label3.setText("Correct!")
		self.BLButton3.setBackground(Color.green)
	def BRCheck3(self, event):
		self.BRButton3.setBackground(Color.red)

	def TLCheck4(self, event):
		self.TLButton4.setBackground(Color.red)
	def TRCheck4(self, event):
		self.TRButton4.setBackground(Color.red)
	def BLCheck4(self, event):
		self.BLButton4.setBackground(Color.red)
	def BRCheck4(self, event):
		self.label4.setText("Correct!")
		self.BRButton4.setBackground(Color.green)
		
	def __init__(self):
		frame = JFrame("2x2 Image Transformation Game")
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
		frame.setSize(1920, 1080)
		frame.setLayout(GridLayout(2, 3))

		#Create 4 panels for input
		radio1 = JPanel(GridLayout(5, 1))
		radio1.setBackground(Color(66, 66, 66))
		frame.add(radio1)
		form1 = lister[0]
		self.TLButton1 = JButton("Top Left", actionPerformed = self.TLCheck1)
		self.TRButton1 = JButton("Top Right", actionPerformed = self.TRCheck1)
		self.BLButton1 = JButton("Bottom Left", actionPerformed = self.BLCheck1)
		self.BRButton1 = JButton("Bottom Right", actionPerformed = self.BRCheck1)
		form1 = lister[0]
		self.label1 = JLabel(form1, JLabel.CENTER)
		self.label1.setFont(Font("Georgia", Font.BOLD, 16))
		self.label1.setForeground(Color.white)
		self.TLButton1.setBackground(Color.white)
		self.TRButton1.setBackground(Color.white)
		self.BLButton1.setBackground(Color.white)
		self.BRButton1.setBackground(Color.white)
		radio1.add(self.label1)
		radio1.add(self.TLButton1)
		radio1.add(self.TRButton1)
		radio1.add(self.BLButton1)
		radio1.add(self.BRButton1)
		
		radio2 = JPanel(GridLayout(5, 1))
		radio2.setBackground(Color(66, 66, 66))
		frame.add(radio2)
		self.TLButton2 = JButton("Top Left", actionPerformed = self.TLCheck2)
		self.TRButton2 = JButton("Top Right", actionPerformed = self.TRCheck2)
		self.BLButton2 = JButton("Bottom Left", actionPerformed = self.BLCheck2)
		self.BRButton2 = JButton("Bottom Right", actionPerformed = self.BRCheck2)
		form2 = lister[1]
		self.label2 = JLabel(form2, JLabel.CENTER)
		self.label2.setFont(Font("Georgia", Font.BOLD, 16))
		self.label2.setForeground(Color.white)
		self.TLButton2.setBackground(Color.white)
		self.TRButton2.setBackground(Color.white)
		self.BLButton2.setBackground(Color.white)
		self.BRButton2.setBackground(Color.white)
		radio2.add(self.label2)
		radio2.add(self.TLButton2)
		radio2.add(self.TRButton2)
		radio2.add(self.BLButton2)
		radio2.add(self.BRButton2)

		radio3 = JPanel(GridLayout(5, 1))
		radio3.setBackground(Color(66, 66, 66))
		frame.add(radio3)
		self.TLButton3 = JButton("Top Left", actionPerformed = self.TLCheck3)
		self.TRButton3 = JButton("Top Right", actionPerformed = self.TRCheck3)
		self.BLButton3 = JButton("Bottom Left", actionPerformed = self.BLCheck3)
		self.BRButton3 = JButton("Bottom Right", actionPerformed = self.BRCheck3)
		form3 = lister[2]
		self.label3 = JLabel(form3, JLabel.CENTER)
		self.label3.setFont(Font("Georgia", Font.BOLD, 16))
		self.label3.setForeground(Color.white)
		self.TLButton3.setBackground(Color.white)
		self.TRButton3.setBackground(Color.white)
		self.BLButton3.setBackground(Color.white)
		self.BRButton3.setBackground(Color.white)
		radio3.add(self.label3)
		radio3.add(self.TLButton3)
		radio3.add(self.TRButton3)
		radio3.add(self.BLButton3)
		radio3.add(self.BRButton3)

		image1 = JPanel(GridLayout(1, 1))
		image1.setBackground(Color(66, 66, 66))
		origin = ImageIcon("2x2FinalProject/OriginalImage.jpg")
		originLabel = JLabel(origin)
		originLabel.setBounds(20, 20, 512, 512)
		image1.add(originLabel)
		frame.add(image1)
		
		radio4 = JPanel(GridLayout(5, 1))
		radio4.setBackground(Color(66, 66, 66))
		frame.add(radio4)
		self.TLButton4 = JButton("Top Left", actionPerformed = self.TLCheck4)
		self.TRButton4 = JButton("Top Right", actionPerformed = self.TRCheck4)
		self.BLButton4 = JButton("Bottom Left", actionPerformed = self.BLCheck4)
		self.BRButton4 = JButton("Bottom Right", actionPerformed = self.BRCheck4)
		form4 = lister[3]
		self.label4 = JLabel(form4, JLabel.CENTER)
		self.label4.setFont(Font("Georgia", Font.BOLD, 16))
		self.label4.setForeground(Color.white)
		self.TLButton4.setBackground(Color.white)
		self.TRButton4.setBackground(Color.white)
		self.BLButton4.setBackground(Color.white)
		self.BRButton4.setBackground(Color.white)
		radio4.add(self.label4)
		radio4.add(self.TLButton4)
		radio4.add(self.TRButton4)
		radio4.add(self.BLButton4)
		radio4.add(self.BRButton4)

		image2 = JPanel(GridLayout(1, 1))
		image2.setBackground(Color(66, 66, 66))
		transform = ImageIcon("2x2FinalProject/Transformed.jpg")
		transformLabel = JLabel(transform)
		transformLabel.setBounds(20, 20, 512, 512)

		image2.add(transformLabel)
		frame.add(image2)

		frame.pack()
		frame.setVisible(1) # Makes the window appear
		print "Playing Game"

#if __name__ == '__main__':
generateImage()
distortImage()
#open the pane
openPane()
